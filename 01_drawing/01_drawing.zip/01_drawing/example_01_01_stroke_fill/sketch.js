// Learning Processing
// Daniel Shiffman
// http://www.learningprocessing.com

// Example 1-1: stroke and fill

function setup() {
  createCanvas(480, 270);
  background(255);
  stroke(0); 
  fill(150);
  rect(50,50,75,100);
}
