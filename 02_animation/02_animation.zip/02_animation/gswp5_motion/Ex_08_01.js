function draw() {
  var fr = frameRate();
  print(fr);
}