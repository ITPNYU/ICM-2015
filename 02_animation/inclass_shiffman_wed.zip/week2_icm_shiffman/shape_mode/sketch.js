function setup() {
  createCanvas(400,400);
}

function draw() {
  background(0);
  stroke(255);
  strokeWeight(2);
  noFill();
  rectMode(CENTER);
  rect(200,200, 150, 75);
}