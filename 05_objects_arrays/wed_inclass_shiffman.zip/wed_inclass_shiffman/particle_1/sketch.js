var particle;

function setup() {
  createCanvas(400, 400);
  
  particle = {
    x: 100,
    y: 50,
    display: function() {
      ellipse(particle.x, particle.y, 24, 24);
    }
  };
}

function draw() {
  background(0);
  particle.display();


}