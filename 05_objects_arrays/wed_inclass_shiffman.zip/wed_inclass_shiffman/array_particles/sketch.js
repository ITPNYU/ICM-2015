var particleList = [];

function setup() {
  createCanvas(400, 400);
  for (var i = 0; i < 213; i++) {
    particleList[i] = {
      x: random(0, 400),
      y: random(0, 400),
      display: function() {
        fill(255, 100);
        ellipse(this.x, this.y, 24, 24);
      },
      move: function() {
        this.x += random(-1, 1);
        this.y += random(-1, 1);
      },
    };
  }
}

function draw() {
  background(0);
  for (var i = 0; i < particleList.length; i++) {
    particleList[i].display();
    particleList[i].move();
  }
}