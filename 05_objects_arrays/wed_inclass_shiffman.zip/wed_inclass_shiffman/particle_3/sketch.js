var particle;

function setup() {
  createCanvas(400, 400);
  particle = {
    x: random(0, 400),
    y: 200,
    diameter: random(20, 80),
    r: 255,
    display: function() {
      fill(this.r, 0, 0);
      ellipse(this.x, this.y, this.diameter, this.diameter);
    },
    move: function() {
      this.y += random(-1, 1);
    },
    changeSize: function() {
      this.diameter = random(100, 200);
    }
  };
}

function keyPressed() {
  particle.changeSize();
}

function mousePressed() {
  // particle.diameter = random(100, 200);
  particle.changeSize();
}

function draw() {
  background(0);
  particle.display();
  particle.move();
}