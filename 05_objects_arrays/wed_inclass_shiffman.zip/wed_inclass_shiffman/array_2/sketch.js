var words;
var index = 0;

function setup() {
  createCanvas(400, 400);
  words = ["hello", "goodbye", "rainbow", "heart"];
  println(words);
  words.push("another");
  //words[4] = "another";
  println(words);
  
  background(0);
  fill(255);
  textSize(32);
}

function mousePressed() {
  index = index + 1;
  if (index == words.length) {
    index = 0;
  }
}

function draw() {
  background(0);
  text(words[index], 10, 100);
}