var particle1;
var particle2;

function setup() {
  createCanvas(400, 400);

  particle1 = {
    x: 100,
    y: 50,
    display: function() {
      ellipse(this.x, this.y, 24, 24);
    }
  };

  particle2 = {
    x: 200,
    y: 50,
    display: function() {
      ellipse(this.x, this.y, 24, 24);
    }
  };
}

function draw() {
  background(0);
  particle.display();


}