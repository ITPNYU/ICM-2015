var num = 5;
var nums = [5, 12, 24, -23, 99, 70];


function setup() {
  createCanvas(400, 400);
}

function draw() {
  
  background(0);
  
  ellipse(100, 200, num, num);

  ellipse(200, 200, nums[2], nums[2]);
  
}