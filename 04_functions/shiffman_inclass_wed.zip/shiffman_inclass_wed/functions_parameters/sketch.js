function setup() {
  createCanvas(400, 300);
}

function draw() {
  background(0);
  
  // for (var i = 0; i < 400; i+=50) {
  //   rainbow(i, 100);
  // }
  
  rainbow(100, 100);
  rainbow(200, 100);
  rainbow(250, 175);
}

function rainbow(x, y) {
  fill(255,0,200);
  ellipse(x, y, 50, 50);
  fill(0,255,200);
  ellipse(x, y+25, 50, 50);
}