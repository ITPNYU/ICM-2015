var gravity = 0.1;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  ball.display();
  ball.move();
  ball.bounce();
}