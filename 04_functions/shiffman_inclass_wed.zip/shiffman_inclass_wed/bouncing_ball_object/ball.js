var ball = {
  x: 300,
  y: 10,
  speed: 1,
  display: function() {
    fill(255);
    ellipse(this.x, this.y, 24, 24);
  },
  move: function() {
    this.y = this.y + this.speed;
    this.speed = this.speed + gravity;
  },
  bounce: function() {
    if (this.y > height) {
      this.speed = -1 * this.speed;
    }
  }
}

//var ball2 = Object.create(ball);