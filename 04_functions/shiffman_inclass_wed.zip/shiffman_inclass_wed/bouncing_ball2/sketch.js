// var x = 300;
// var y = 10
// var speed = 1;

var ball = {
  x: 300,
  y: 10,
  speed: 1
}

var gravity = 0.1;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  ball.display();
  ball.move();
  ball.bounce();

}




