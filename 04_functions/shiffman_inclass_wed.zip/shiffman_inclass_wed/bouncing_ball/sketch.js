// var x = 300;
// var y = 10
// var speed = 1;

var ball = {
  x: 300,
  y: 10,
  speed: 1
}

// var ball2 = {
//   x: 200,
//   y: 10,
//   speed: 3
// }

var gravity = 0.1;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  
  background(0);

  fill(255);
  ellipse(ball.x, ball.y, 24, 24);
  
  ball.y = ball.y + ball.speed;
  ball.speed = ball.speed + gravity;

  if (ball.y > height) {
    ball.speed = -1*ball.speed;
  }
  
}